<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Textil Smart - Página Principal</title>
    <link rel="stylesheet" href="estilos.css">
    <script src="scripts.js" defer></script>
</head>
<body>
    <header>
        <img src="assets/industria-textil.jpg" alt="Logo de la empresa">
        <h1>Bienvenido a Textil Smart</h1>
        <nav>
            <ul>
                <!-- Cambia aquí el enlace de Materia Prima -->
                <li><a href="../views/materia_prima.php">Materia Prima</a></li>
                <li><a href="../views/productos_terminados.php">Productos Terminados</a></li>
                <li><a href="../views/produccion.php">Producción</a></li>
                <li><a href="../views/clientes.php">Clientes</a></li>
                <li><a href="../views/pedidos.php">Pedidos</a></li>
                <li><a href="../views/distribucion.php">Distribución</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <section>
            <h2>Descripción del Sistema</h2>
            <p>
                Textil Smart es un sistema para gestionar la materia prima, productos terminados, 
                procesos de producción, clientes y pedidos en la industria textil.
            </p>
        </section>
    </main>

    <footer>
        <p>&copy; 2024 Textil Smart. Todos los derechos reservados.</p>
    </footer>
</body>
</html>
