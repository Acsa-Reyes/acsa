// scripts.js

document.addEventListener('DOMContentLoaded', () => {
    // Selecciona todos los enlaces que redirigen a las interfaces
    const links = [
        { selector: 'a[href="views/materia_prima.php"]', url: 'views/materia_prima.php' },
        { selector: 'a[href="views/productos_terminados.php"]', url: 'views/productos_terminados.php' },
        { selector: 'a[href="views/produccion.php"]', url: 'views/produccion.php' },
        { selector: 'a[href="views/clientes.php"]', url: 'views/clientes.php' },
        { selector: 'a[href="views/pedidos.php"]', url: 'views/pedidos.php' },
        { selector: 'a[href="views/distribucion.php"]', url: 'views/distribucion.php' },
    ];

    // Añade el evento de clic a cada enlace
    links.forEach(link => {
        const element = document.querySelector(link.selector);
        if (element) {
            element.addEventListener('click', (event) => {
                event.preventDefault(); // Evita el comportamiento predeterminado del enlace
                window.location.href = link.url; // Redirige a la interfaz correspondiente
            });
        }
    });
});
