<?php
// src/Cliente.php

class Cliente {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    // Método para agregar un nuevo cliente
    public function agregarCliente($nombre, $email, $telefono, $direccion) {
        $sql = "INSERT INTO cliente (nombre, email, telefono, direccion) VALUES (:nombre, :email, :telefono, :direccion)";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([
            'nombre' => $nombre,
            'email' => $email,
            'telefono' => $telefono,
            'direccion' => $direccion
        ]);
    }

    // Método para obtener todos los clientes
    public function obtenerClientes() {
        $sql = "SELECT * FROM cliente";
        $stmt = $this->pdo->query($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Método para obtener un cliente por ID
    public function obtenerClientePorId($id) {
        $sql = "SELECT * FROM cliente WHERE id = :id";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute(['id' => $id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Método para actualizar cliente
    public function actualizarCliente($id, $nombre, $email, $telefono, $direccion) {
        $sql = "UPDATE cliente SET nombre = :nombre, email = :email, telefono = :telefono, direccion = :direccion WHERE id = :id";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([
            'id' => $id,
            'nombre' => $nombre,
            'email' => $email,
            'telefono' => $telefono,
            'direccion' => $direccion
        ]);
    }

    // Método para eliminar cliente
    public function eliminarCliente($id) {
        $sql = "DELETE FROM cliente WHERE id = :id";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute(['id' => $id]);
    }
}