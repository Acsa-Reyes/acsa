<?php
// src/Distribucion.php

class Distribucion {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    // Método para registrar una nueva distribución
    public function registrarDistribucion($pedido_id, $fecha_envio, $estado) {
        $sql = "INSERT INTO distribucion (pedido_id, fecha_envio, estado) VALUES (:pedido_id, :fecha_envio, :estado)";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([
            'pedido_id' => $pedido_id,
            'fecha_envio' => $fecha_envio,
            'estado' => $estado
        ]);
    }

    // Método para obtener todas las distribuciones
    public function obtenerDistribuciones() {
        $sql = "SELECT d.id, d.fecha_envio, d.estado, p.id AS pedido_id 
                FROM distribucion d
                JOIN pedido p ON d.pedido_id = p.id"; // Asegúrate de que la tabla 'pedido' se llama así
        $stmt = $this->pdo->query($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Método para obtener una distribución por ID
    public function obtenerDistribucionPorId($id) {
        $sql = "SELECT * FROM distribucion WHERE id = :id";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute(['id' => $id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Método para actualizar una distribución
    public function actualizarDistribucion($id, $pedido_id, $fecha_envio, $estado) {
        $sql = "UPDATE distribucion SET pedido_id = :pedido_id, fecha_envio = :fecha_envio, estado = :estado WHERE id = :id";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([
            'id' => $id,
            'pedido_id' => $pedido_id,
            'fecha_envio' => $fecha_envio,
            'estado' => $estado
        ]);
    }

    // Método para eliminar una distribución
    public function eliminarDistribucion($id) {
        $sql = "DELETE FROM distribucion WHERE id = :id";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute(['id' => $id]);
    }

    public function eliminarDistribucionesPorPedido($pedido_id) {
        $sql = "DELETE FROM distribucion WHERE pedido_id = :pedido_id";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute(['pedido_id' => $pedido_id]);
    }
}
