<?php
// src/MateriaPrima.php

class MateriaPrima {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    // Método para registrar una nueva materia prima
    public function registrarMateriaPrima($nombre, $cantidad, $unidad_medida, $precio_unidad) {
        $sql = "INSERT INTO materia_prima (nombre, cantidad, unidad_medida, precio_unitario) VALUES (:nombre, :cantidad, :unidad_medida, :precio_unitario)";
        $stmt = $this->pdo->prepare($sql);
        try {
            $stmt->execute([
                'nombre' => $nombre,
                'cantidad' => $cantidad,
                'unidad_medida' => $unidad_medida,
                'precio_unitario' => $precio_unidad
            ]);
        } catch (PDOException $e) {
            echo "Error: " . $e->getMessage();
        }
    }

    // Método para obtener todas las materias primas
    public function obtenerMateriasPrimas() {
        $sql = "SELECT * FROM materia_prima";
        $stmt = $this->pdo->query($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Método para obtener una materia prima por ID
    public function obtenerMateriaPrimaPorId($id) {
        $sql = "SELECT * FROM materia_prima WHERE id = :id";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute(['id' => $id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Método para actualizar una materia prima
    public function actualizarMateriaPrima($id, $nombre, $cantidad, $unidad_medida, $precio_unidad) {
        $sql = "UPDATE materia_prima SET nombre = :nombre, cantidad = :cantidad, unidad_medida = :unidad_medida, precio_unitario = :precio_unitario WHERE id = :id";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([
            'id' => $id,
            'nombre' => $nombre,
            'cantidad' => $cantidad,
            'unidad_medida' => $unidad_medida,
            'precio_unitario' => $precio_unidad
        ]);
    }

    // Método para eliminar una materia prima
    public function eliminarMateriaPrima($id) {
        $sql = "DELETE FROM materia_prima WHERE id = :id";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute(['id' => $id]);
    }
}
