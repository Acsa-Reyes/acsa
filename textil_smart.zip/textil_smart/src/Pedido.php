<?php
// src/Pedido.php

class Pedido {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    // Método para agregar un nuevo pedido
    public function agregarPedido($cliente_id, $producto_id, $cantidad, $fecha_pedido) {
        $sql = "INSERT INTO pedido (cliente_id, producto_id, cantidad, fecha_pedido) VALUES (:cliente_id, :producto_id, :cantidad, :fecha_pedido)";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([
            'cliente_id' => $cliente_id,
            'producto_id' => $producto_id,
            'cantidad' => $cantidad,
            'fecha_pedido' => $fecha_pedido
        ]);
    }

    // Método para obtener todos los pedidos
    public function obtenerPedidos() {
        $sql = "SELECT p.id, c.nombre AS cliente, pt.nombre AS producto, p.cantidad, p.fecha_pedido 
                FROM pedido p
                JOIN cliente c ON p.cliente_id = c.id
                JOIN producto_terminado pt ON p.producto_id = pt.id";
        $stmt = $this->pdo->query($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Método para obtener un pedido por ID
    public function obtenerPedidoPorId($id) {
        $sql = "SELECT * FROM pedido WHERE id = :id";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute(['id' => $id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Método para actualizar un pedido
    public function actualizarPedido($id, $cliente_id, $producto_id, $cantidad, $fecha_pedido) {
        $sql = "UPDATE pedido SET cliente_id = :cliente_id, producto_id = :producto_id, cantidad = :cantidad, fecha_pedido = :fecha_pedido WHERE id = :id";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([
            'id' => $id,
            'cliente_id' => $cliente_id,
            'producto_id' => $producto_id,
            'cantidad' => $cantidad,
            'fecha_pedido' => $fecha_pedido
        ]);
    }

    // Método para eliminar un pedido
    public function eliminarPedido($id) {
        $sql = "DELETE FROM pedido WHERE id = :id";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute(['id' => $id]);
    }

    // Método en Pedido.php para eliminar pedidos por producto_id
    public function eliminarPedidosPorProducto($producto_id) {
        $sql = "DELETE FROM pedido WHERE producto_id = :producto_id";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute(['producto_id' => $producto_id]);
    }
}
