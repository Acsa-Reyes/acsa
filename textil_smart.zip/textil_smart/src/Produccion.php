<?php
// src/Produccion.php

class Produccion {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    // Método para agregar un nuevo proceso de producción
    public function agregarProduccion($producto_id, $materia_prima_id, $cantidad_producida, $fecha) {
        try {
            $sql = "INSERT INTO produccion (producto_id, materia_prima_id, cantidad_producida, fecha) VALUES (:producto_id, :materia_prima_id, :cantidad_producida, :fecha)";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([
                'producto_id' => $producto_id,
                'materia_prima_id' => $materia_prima_id,
                'cantidad_producida' => $cantidad_producida,
                'fecha' => $fecha
            ]);
        } catch (PDOException $e) {
            echo "Error: " . $e->getMessage();
        }
    }

    // Método para obtener todos los procesos de producción
    public function obtenerProducciones() {
        $sql = "SELECT p.id, pt.nombre AS producto, mp.nombre AS materia_prima, p.cantidad_producida, p.fecha
                FROM produccion p
                JOIN producto_terminado pt ON p.producto_id = pt.id
                JOIN materia_prima mp ON p.materia_prima_id = mp.id";
        $stmt = $this->pdo->query($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Método para obtener un proceso de producción por ID
    public function obtenerProduccionPorId($id) {
        $sql = "SELECT * FROM produccion WHERE id = :id";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute(['id' => $id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Método para actualizar un proceso de producción
    public function actualizarProduccion($id, $producto_id, $materia_prima_id, $cantidad_producida, $fecha) {
        try {
            $sql = "UPDATE produccion SET producto_id = :producto_id, materia_prima_id = :materia_prima_id, cantidad_producida = :cantidad_producida, fecha = :fecha WHERE id = :id";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([
                'producto_id' => $producto_id,
                'materia_prima_id' => $materia_prima_id,
                'cantidad_producida' => $cantidad_producida,
                'fecha' => $fecha,
                'id' => $id
            ]);
        } catch (PDOException $e) {
            echo "Error: " . $e->getMessage();
        }
    }

    // Método para eliminar un proceso de producción
    public function eliminarProduccion($id) {
        try {
            $sql = "DELETE FROM produccion WHERE id = :id";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute(['id' => $id]);
        } catch (PDOException $e) {
            echo "Error: " . $e->getMessage();
        }
    }
}
