<?php
// src/ProductoTerminado.php

class ProductoTerminado {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    // Método para agregar un nuevo producto terminado
    public function agregarProductoTerminado($nombre, $descripcion, $precio, $stock) {
        $sql = "INSERT INTO producto_terminado (nombre, descripcion, precio, stock) VALUES (:nombre, :descripcion, :precio, :stock)";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([
            'nombre' => $nombre,
            'descripcion' => $descripcion,
            'precio' => $precio,
            'stock' => $stock
        ]);
    }

    // Método para obtener todos los productos terminados, sumando stock de duplicados
    public function obtenerProductosTerminados() {
        $sql = "SELECT id, nombre, descripcion, precio, SUM(stock) AS stock 
                FROM producto_terminado 
                GROUP BY id, nombre, descripcion, precio";
        $stmt = $this->pdo->query($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Método para obtener un producto terminado por ID
    public function obtenerProductoTerminadoPorId($id) {
        $sql = "SELECT * FROM producto_terminado WHERE id = :id";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute(['id' => $id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Método para obtener un producto terminado por nombre, descripción y precio
    public function obtenerProductoTerminadoPorNombreDescripcionPrecio($nombre, $descripcion, $precio) {
        $sql = "SELECT * FROM producto_terminado WHERE nombre = :nombre AND descripcion = :descripcion AND precio = :precio";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute(['nombre' => $nombre, 'descripcion' => $descripcion, 'precio' => $precio]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Método para actualizar producto terminado
    public function actualizarProductoTerminado($id, $nombre, $descripcion, $precio, $stock) {
        $sql = "UPDATE producto_terminado SET nombre = :nombre, descripcion = :descripcion, precio = :precio, stock = :stock WHERE id = :id";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([
            'id' => $id,
            'nombre' => $nombre,
            'descripcion' => $descripcion,
            'precio' => $precio,
            'stock' => $stock
        ]);
    }

    // Método para actualizar el stock de un producto
    public function actualizarStock($id, $nuevoStock) {
        $sql = "UPDATE producto_terminado SET stock = :stock WHERE id = :id";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([
            'id' => $id,
            'stock' => $nuevoStock
        ]);
    }

    // Método para eliminar producto terminado
    public function eliminarProductoTerminado($id) {
        $sql = "DELETE FROM producto_terminado WHERE id = :id";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute(['id' => $id]);
    }
}