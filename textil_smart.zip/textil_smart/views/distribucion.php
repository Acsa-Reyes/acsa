<?php
// views/distribuciones.php

require_once '../config/database.php';
require_once '../src/Distribucion.php';
require_once '../src/Pedido.php'; // Asegúrate de tener esta clase para obtener pedidos

$distribucion = new Distribucion($pdo);
$pedido = new Pedido($pdo);

// Manejo de registro de nueva distribución
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['registrar'])) {
    $pedido_id = $_POST['pedido_id'];
    $fecha_envio = $_POST['fecha_envio'];
    $estado = $_POST['estado'];
    $distribucion->registrarDistribucion($pedido_id, $fecha_envio, $estado);
}

// Obtener todas las distribuciones
$distribuciones = $distribucion->obtenerDistribuciones();
$pedidos = $pedido->obtenerPedidos(); // Para obtener los pedidos disponibles
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Distribuciones - Textil Smart</title>
    <link rel="stylesheet" href="../public/estilos.css">
</head>
<body>
    <header>
        <h1>Gestión de Distribuciones</h1>
    </header>

    <nav>
        <ul>
            <!-- Cambia aquí el enlace de Materia Prima -->
            <li><a href="../views/productos_terminados.php">Productos Terminados</a></li>
            <li><a href="../views/produccion.php">Producción</a></li>
            <li><a href="../views/materia_prima.php">Materia Prima</a></li>
            <li><a href="../views/pedidos.php">Pedidos</a></li>
            <li><a href="../views/clientes.php">Clientes</a></li>
        </ul>
    </nav>

    <main>
        <section>
            <h2>Registrar Nueva Distribución</h2>
            <form method="POST">
                <label for="pedido_id">Pedido:</label>
                <select id="pedido_id" name="pedido_id" required>
                    <?php foreach ($pedidos as $pedido): ?>
                        <option value="<?= $pedido['id'] ?>"><?= $pedido['producto'] ?></option> <!-- Ajusta si es necesario -->
                    <?php endforeach; ?>
                </select>

                <label for="fecha_envio">Fecha de Envío:</label>
                <input type="date" id="fecha_envio" name="fecha_envio" required>

                <label for="estado">Estado:</label>
                <input type="text" id="estado" name="estado" required>

                <button type="submit" name="registrar">Registrar Distribución</button>
            </form>
        </section>

        <section>
            <h2>Lista de Distribuciones</h2>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Pedido ID</th>
                        <th>Fecha de Envío</th>
                        <th>Estado</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($distribuciones as $d): ?>
                        <tr>
                            <td><?= $d['id'] ?></td>
                            <td><?= $d['pedido_id'] ?></td>
                            <td><?= $d['fecha_envio'] ?></td>
                            <td><?= $d['estado'] ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </section>
    </main>

    <footer>
        <p>&copy; 2024 Textil Smart. Todos los derechos reservados.</p>
    </footer>
</body>
</html>
