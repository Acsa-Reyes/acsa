<?php
session_start(); // Iniciar la sesión

require_once '../config/database.php';
require_once '../src/Cliente.php';

$cliente = new Cliente($pdo);

// Verificar si se ha pasado un ID
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $clienteData = $cliente->obtenerClientePorId($id);

    // Manejo de actualización
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['actualizar'])) {
        $nombre = $_POST['nombre'];
        $email = $_POST['email'];
        $telefono = $_POST['telefono'];
        $direccion = $_POST['direccion'];

        $cliente->actualizarCliente($id, $nombre, $email, $telefono, $direccion);
        
        // Almacenar mensaje de éxito en la sesión
        $_SESSION['mensaje'] = 'Cliente actualizado con éxito.';
        
        // Redirigir a la página de clientes
        header("Location: ./clientes.php");
        exit();
    }
} else {
    // Redirigir si no se proporciona un ID
    header("Location: ./clientes.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Cliente - Textil Smart</title>
    <link rel="stylesheet" href="../public/estilos.css">
</head>
<body>
    <header>
        <h1>Editar Cliente</h1>
    </header>

    <main>
        <section>
            <form method="POST">
                <label for="nombre">Nombre:</label>
                <input type="text" id="nombre" name="nombre" value="<?= htmlspecialchars($clienteData['nombre']) ?>" required>

                <label for="email">Email:</label>
                <input type="email" id="email" name="email" value="<?= htmlspecialchars($clienteData['email']) ?>" required>

                <label for="telefono">Teléfono:</label>
                <input type="tel" id="telefono" name="telefono" value="<?= htmlspecialchars($clienteData['telefono']) ?>" required>

                <label for="direccion">Dirección:</label>
                <input type="text" id="direccion" name="direccion" value="<?= htmlspecialchars($clienteData['direccion']) ?>" required>

                <button type="submit" name="actualizar">Actualizar Cliente</button>
            </form>
        </section>
    </main>

    <footer>
        <p>&copy; 2024 Textil Smart. Todos los derechos reservados.</p>
    </footer>
</body>
</html>