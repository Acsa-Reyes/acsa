<?php
session_start(); // Iniciar la sesión

require_once '../config/database.php';
require_once '../src/MateriaPrima.php';

$materiaPrima = new MateriaPrima($pdo);

// Verificar si se ha pasado un ID
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $materia = $materiaPrima->obtenerMateriaPrimaPorId($id);

    // Manejo de actualización
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['actualizar'])) {
        $nombre = $_POST['nombre'];
        $cantidad = $_POST['cantidad'];
        $unidad_medida = $_POST['unidad_medida'];
        $precio_unitario = $_POST['precio_unitario'];
        
        $materiaPrima->actualizarMateriaPrima($id, $nombre, $cantidad, $unidad_medida, $precio_unitario);
        
        // Almacenar mensaje de éxito en la sesión
        $_SESSION['mensaje'] = 'Materia prima actualizada con éxito.';
        
        // Redirigir a la página de materias primas
        header("Location: ./materia_prima.php");
        exit();
    }
} else {
    // Redirigir si no se proporciona un ID
    header("Location: ./materia_prima.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Materia Prima</title>
    <link rel="stylesheet" href="../public/estilos.css">
</head>
<body>
    <header>
        <h1>Editar Materia Prima</h1>
    </header>

    <main>
        <section>
            <form method="POST">
                <label for="nombre">Nombre:</label>
                <input type="text" id="nombre" name="nombre" value="<?= htmlspecialchars($materia['nombre']) ?>" required>

                <label for="cantidad">Cantidad:</label>
                <input type="number" id="cantidad" name="cantidad" value="<?= htmlspecialchars($materia['cantidad']) ?>" required>

                <label for="unidad_medida">Unidad de Medida:</label>
                <input type="text" id="unidad_medida" name="unidad_medida" value="<?= htmlspecialchars($materia['unidad_medida']) ?>" required>

                <label for="precio_unitario">Precio por Unidad:</label>
                <input type="number" step="0.01" id="precio_unitario" name="precio_unitario" value="<?= htmlspecialchars($materia['precio_unitario']) ?>" required>

                <button type="submit" name="actualizar">Actualizar Materia Prima</button>
            </form>
        </section>
    </main>

    <footer>
        <p>&copy; 2024 Textil Smart. Todos los derechos reservados.</p>
    </footer>
</body>
</html>