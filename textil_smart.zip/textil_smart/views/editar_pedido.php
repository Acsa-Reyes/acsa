<?php
session_start(); // Iniciar la sesión

require_once '../config/database.php';
require_once '../src/Pedido.php';
require_once '../src/Cliente.php';
require_once '../src/ProductoTerminado.php';

$pedido = new Pedido($pdo);
$cliente = new Cliente($pdo);
$productoTerminado = new ProductoTerminado($pdo);

// Verificar si se ha pasado un ID
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $pedidoData = $pedido->obtenerPedidoPorId($id);
    $clientes = $cliente->obtenerClientes();
    $productosTerminados = $productoTerminado->obtenerProductosTerminados();

    // Manejo de actualización
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['actualizar'])) {
        $cliente_id = $_POST['cliente_id'];
        $producto_id = $_POST['producto_id'];
        $cantidad = $_POST['cantidad'];
        $fecha_pedido = $_POST['fecha_pedido'];

        $pedido->actualizarPedido($id, $cliente_id, $producto_id, $cantidad, $fecha_pedido);
        $_SESSION['mensaje'] = 'Pedido actualizado con éxito.';
        header("Location: ./pedidos.php");
        exit();
    }
} else {
    // Redirigir si no se proporciona un ID
    header("Location: ./pedidos.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Pedido - Textil Smart</title>
    <link rel="stylesheet" href="../public/estilos.css">
</head>
<body>
    <header>
        <h1>Editar Pedido</h1>
    </header>

    <main>
        <section>
            <form method="POST">
                <label for="cliente_id">Cliente:</label>
                <select id="cliente_id" name="cliente_id" required>
                    <?php foreach ($clientes as $c): ?>
                        <option value="<?= $c['id'] ?>" <?= $c['id'] === $pedidoData['cliente_id'] ? 'selected' : '' ?>><?= htmlspecialchars($c['nombre']) ?></option>
                    <?php endforeach; ?>
                </select>

                <label for="producto_id">Producto:</label>
                <select id="producto_id" name="producto_id" required>
                    <?php foreach ($productosTerminados as $producto): ?>
                        <option value="<?= $producto['id'] ?>" <?= $producto['id'] === $pedidoData['producto_id'] ? 'selected' : '' ?>><?= htmlspecialchars($producto['nombre']) ?></option>
                    <?php endforeach; ?>
                </select>

                <label for="cantidad">Cantidad:</label>
                <input type="number" id="cantidad" name="cantidad" value="<?= htmlspecialchars($pedidoData['cantidad']) ?>" required>

                <label for="fecha_pedido">Fecha de Pedido:</label>
                <input type="date" id="fecha_pedido" name="fecha_pedido" value="<?= htmlspecialchars($pedidoData['fecha_pedido']) ?>" required>

                <button type="submit" name="actualizar">Actualizar Pedido</button>
            </form>
        </section>
    </main>

    <footer>
        <p>&copy; 2024 Textil Smart. Todos los derechos reservados.</p>
    </footer>
</body>
</html>