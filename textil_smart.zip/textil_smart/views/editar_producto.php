<?php
session_start(); // Iniciar la sesión

require_once '../config/database.php';
require_once '../src/ProductoTerminado.php';

$productoTerminado = new ProductoTerminado($pdo);

// Verificar si se ha pasado un ID
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $productoData = $productoTerminado->obtenerProductoTerminadoPorId($id);

    if (!$productoData) {
        // Redirigir si no se encuentra el producto
        header("Location: productos_terminados.php");
        exit();
    }

    // Manejo de actualización
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['actualizar'])) {
        $nombre = $_POST['nombre'];
        $descripcion = $_POST['descripcion'];
        $precio = $_POST['precio'];
        $stock = $_POST['stock'];

        $productoTerminado->actualizarProductoTerminado($id, $nombre, $descripcion, $precio, $stock);
        $_SESSION['mensaje'] = 'Producto actualizado con éxito.';
        header("Location: productos_terminados.php"); // Corregir la ruta si es necesario
        exit();
    }
} else {
    // Redirigir si no se proporciona un ID
    header("Location: productos_terminados.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Producto - Textil Smart</title>
    <link rel="stylesheet" href="../public/estilos.css">
</head>
<body>
    <header>
        <h1>Editar Producto Terminado</h1>
    </header>

    <main>
        <section>
            <form method="POST">
                <label for="nombre">Nombre:</label>
                <input type="text" id="nombre" name="nombre" value="<?= htmlspecialchars($productoData['nombre']) ?>" required>

                <label for="descripcion">Descripción:</label>
                <input type="text" id="descripcion" name="descripcion" value="<?= htmlspecialchars($productoData['descripcion']) ?>" required>

                <label for="precio">Precio:</label>
                <input type="number" id="precio" name="precio" value="<?= htmlspecialchars($productoData['precio']) ?>" step="0.01" required>

                <label for="stock">Stock:</label>
                <input type="number" id="stock" name="stock" value="<?= htmlspecialchars($productoData['stock']) ?>" required>

                <button type="submit" name="actualizar">Actualizar Producto</button>
            </form>
        </section>
    </main>

    <footer>
        <p>&copy; 2024 Textil Smart. Todos los derechos reservados.</p>
    </footer>
</body>
</html>