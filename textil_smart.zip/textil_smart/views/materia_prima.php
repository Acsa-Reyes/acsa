<?php
session_start(); // Iniciar la sesión

require_once '../config/database.php';
require_once '../src/MateriaPrima.php';

$materiaPrima = new MateriaPrima($pdo);

// Manejo de registro de nueva materia prima
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['registrar'])) {
    $nombre = $_POST['nombre'];
    $cantidad = $_POST['cantidad'];
    $unidad_medida = $_POST['unidad_medida'];
    $precio_unitario = $_POST['precio_unitario'];
    $materiaPrima->registrarMateriaPrima($nombre, $cantidad, $unidad_medida, $precio_unitario);
}

// Manejo de eliminación
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['eliminar'])) {
    $ids = $_POST['ids'] ?? [];
    foreach ($ids as $id) {
        $materiaPrima->eliminarMateriaPrima($id);
    }
}

// Obtener todas las materias primas
$materiasPrimas = $materiaPrima->obtenerMateriasPrimas();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Materia Prima - Textil Smart</title>
    <link rel="stylesheet" href="../public/estilos.css">
</head>
<body>
    <header>
        <h1>Gestión de Materia Prima</h1>
    </header>

    <nav>
        <ul>
            <li><a href="productos_terminados.php">Productos Terminados</a></li>
            <li><a href="produccion.php">Producción</a></li>
            <li><a href="clientes.php">Clientes</a></li>
            <li><a href="pedidos.php">Pedidos</a></li>
            <li><a href="distribucion.php">Distribución</a></li>
        </ul>
    </nav>

    <main>
        <section>
            <?php if (isset($_SESSION['mensaje'])): ?>
                <div class="mensaje-exito">
                    <?= $_SESSION['mensaje'] ?>
                    <?php unset($_SESSION['mensaje']); // Limpiar el mensaje después de mostrarlo ?>
                </div>
            <?php endif; ?>

            <h2>Registrar Nueva Materia Prima</h2>
            <form method="POST">
                <label for="nombre">Nombre:</label>
                <input type="text" id="nombre" name="nombre" required>

                <label for="cantidad">Cantidad:</label>
                <input type="number" id="cantidad" name="cantidad" required>

                <label for="unidad_medida">Unidad de Medida:</label>
                <input type="text" id="unidad_medida" name="unidad_medida" required>

                <label for="precio_unitario">Precio por Unidad:</label>
                <input type="number" step="0.01" id="precio_unitario" name="precio_unitario" required>

                <button type="submit" name="registrar">Registrar Materia Prima</button>
            </form>
        </section>

        <section>
            <h2>Lista de Materias Primas</h2>
            <form method="POST">
                <table>
                    <thead>
                        <tr>
                            <th>Seleccionar</th>
                            <th>ID</th>
                            <th>Nombre</th>
                            <th>Cantidad</th>
                            <th>Unidad de Medida</th>
                            <th>Precio por Unidad</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($materiasPrimas as $mp): ?>
                            <tr>
                                <td><input type="checkbox" name="ids[]" value="<?= $mp['id'] ?>"></td>
                                <td><?= $mp['id'] ?></td>
                                <td><?= $mp['nombre'] ?></td>
                                <td><?= $mp['cantidad'] ?></td>
                                <td><?= $mp['unidad_medida'] ?></td>
                                <td>$<?= number_format($mp['precio_unitario'], 2) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <button type="submit" name="eliminar">Eliminar Seleccionadas</button>
                <button type="button" onclick="location.href='editar_materia.php?id=' + getSelectedId()">Editar Seleccionada</button>
            </form>
        </section>
    </main>

    <footer>
        <p>&copy; 2024 Textil Smart. Todos los derechos reservados.</p>
    </footer>

    <script>
        function getSelectedId() {
            const checkboxes = document.querySelectorAll('input[name="ids[]"]:checked');
            return checkboxes.length === 1 ? checkboxes[0].value : '';
        }
    </script>
</body>
</html>