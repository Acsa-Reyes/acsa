<?php
session_start(); // Iniciar la sesión

require_once '../config/database.php';
require_once '../src/Pedido.php';
require_once '../src/Cliente.php';
require_once '../src/ProductoTerminado.php';

$pedido = new Pedido($pdo);
$cliente = new Cliente($pdo);
$productoTerminado = new ProductoTerminado($pdo);

// Manejo de inserción de nuevo pedido
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['agregar'])) {
    $cliente_id = $_POST['cliente_id'];
    $producto_id = $_POST['producto_id'];
    $cantidad = $_POST['cantidad'];
    $fecha_pedido = $_POST['fecha_pedido'];

    // Verificación simple antes de insertar
    if (!empty($cliente_id) && !empty($producto_id) && !empty($cantidad) && !empty($fecha_pedido)) {
        // Verificar existencia y stock del producto
        $producto = $productoTerminado->obtenerProductoTerminadoPorId($producto_id);

        if ($producto && $producto['stock'] >= $cantidad) {
            // Agregar el pedido
            $pedido->agregarPedido($cliente_id, $producto_id, $cantidad, $fecha_pedido);
            
            // Descontar del stock
            $nuevo_stock = $producto['stock'] - $cantidad;
            $productoTerminado->actualizarStock($producto_id, $nuevo_stock);
            
            $_SESSION['mensaje'] = 'Pedido generado con éxito.';
        } else {
            $_SESSION['mensaje'] = 'No hay suficiente stock para realizar el pedido.';
        }
    }
}

// Manejo de eliminación de pedidos
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['eliminar'])) {
    $ids = $_POST['pedidos'] ?? [];
    foreach ($ids as $id) {
        $pedido->eliminarPedido($id);
    }
}

// Obtener todos los pedidos
$pedidos = $pedido->obtenerPedidos();
$clientes = $cliente->obtenerClientes();
$productosTerminados = $productoTerminado->obtenerProductosTerminados();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Pedidos - Textil Smart</title>
    <link rel="stylesheet" href="../public/estilos.css">
</head>
<body>
    <header>
        <h1>Gestión de Pedidos</h1>
    </header>

    <nav>
        <ul>
            <li><a href="../views/productos_terminados.php">Productos Terminados</a></li>
            <li><a href="../views/produccion.php">Producción</a></li>
            <li><a href="../views/materia_prima.php">Materia Prima</a></li>
            <li><a href="../views/distribucion.php">Distribución</a></li>
            <li><a href="../views/clientes.php">Clientes</a></li>
        </ul>
    </nav>

    <main>
        <?php if (isset($_SESSION['mensaje'])): ?>
            <div class="mensaje-exito">
                <?= $_SESSION['mensaje'] ?>
                <?php unset($_SESSION['mensaje']); ?>
            </div>
        <?php endif; ?>

        <section>
            <h2>Añadir Nuevo Pedido</h2>
            <form method="POST">
                <label for="cliente_id">Cliente:</label>
                <select id="cliente_id" name="cliente_id" required>
                    <?php foreach ($clientes as $c): ?>
                        <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['nombre']) ?></option>
                    <?php endforeach; ?>
                </select>

                <label for="producto_id">Producto:</label>
                <select id="producto_id" name="producto_id" required>
                    <?php foreach ($productosTerminados as $producto): ?>
                        <option value="<?= $producto['id'] ?>"><?= htmlspecialchars($producto['nombre']) ?></option>
                    <?php endforeach; ?>
                </select>

                <label for="cantidad">Cantidad:</label>
                <input type="number" id="cantidad" name="cantidad" required>

                <label for="fecha_pedido">Fecha de Pedido:</label>
                <input type="date" id="fecha_pedido" name="fecha_pedido" required>

                <button type="submit" name="agregar">Registrar Pedido</button>
            </form>
        </section>

        <section>
            <h2>Lista de Pedidos</h2>
            <form method="POST">
                <table>
                    <thead>
                        <tr>
                            <th>Seleccionar</th>
                            <th>ID</th>
                            <th>Cliente</th>
                            <th>Producto</th>
                            <th>Cantidad</th>
                            <th>Fecha de Pedido</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($pedidos as $p): ?>
                            <tr>
                                <td><input type="checkbox" name="pedidos[]" value="<?= $p['id'] ?>"></td>
                                <td><?= $p['id'] ?></td>
                                <td><?= htmlspecialchars($p['cliente']) ?></td>
                                <td><?= htmlspecialchars($p['producto']) ?></td>
                                <td><?= htmlspecialchars($p['cantidad']) ?></td>
                                <td><?= htmlspecialchars($p['fecha_pedido']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <button type="submit" name="eliminar">Eliminar Seleccionados</button>
                <button type="button" onclick="location.href='editar_pedido.php?id=' + getSelectedId()">Editar Seleccionado</button>
            </form>
        </section>
    </main>

    <footer>
        <p>&copy; 2024 Textil Smart. Todos los derechos reservados.</p>
    </footer>

    <script>
        function getSelectedId() {
            const checkboxes = document.querySelectorAll('input[name="pedidos[]"]:checked');
            return checkboxes.length === 1 ? checkboxes[0].value : '';
        }
    </script>
</body>
</html>