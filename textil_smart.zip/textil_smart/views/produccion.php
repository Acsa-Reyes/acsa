<?php
// views/produccion.php

require_once '../config/database.php';
require_once '../src/Produccion.php';
require_once '../src/ProductoTerminado.php';

$produccion = new Produccion($pdo);
$productoTerminado = new ProductoTerminado($pdo);

// Manejo de inserción de nuevo proceso de producción
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['agregar'])) {
    $producto_id = $_POST['producto_id'];
    $materia_prima_id = $_POST['materia_prima_id'];
    $cantidad_producida = $_POST['cantidad_producida'];
    $fecha = $_POST['fecha'];
    
    // Agregar producción
    $produccion->agregarProduccion($producto_id, $materia_prima_id, $cantidad_producida, $fecha);
}

// Obtener todos los procesos de producción
$producciones = $produccion->obtenerProducciones();
$productosTerminados = $productoTerminado->obtenerProductosTerminados();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Producción - Textil Smart</title>
    <link rel="stylesheet" href="../public/estilos.css">
</head>
<body>
    <header>
        <h1>Gestión de Producción</h1>
    </header>

    <nav>
        <ul>
            <!-- Cambia aquí el enlace de Materia Prima -->
            <li><a href="../views/productos_terminados.php">Productos Terminados</a></li>
            <li><a href="../views/pedidos.php">Pedidos</a></li>
            <li><a href="../views/materia_prima.php">Materia Prima</a></li>
            <li><a href="../views/distribucion.php">Distribucion</a></li>
            <li><a href="../views/clientes.php">Clientes</a></li>
        </ul>
    </nav>

    <main>
        <section>
            <h2>Añadir Nuevo Proceso de Producción</h2>
            <form method="POST">
                <label for="producto_id">Producto:</label>
                <select id="producto_id" name="producto_id" required>
                    <?php foreach ($productosTerminados as $producto): ?>
                        <option value="<?= $producto['id'] ?>"><?= $producto['nombre'] ?></option>
                    <?php endforeach; ?>
                </select>

                <label for="materia_prima_id">Materia Prima:</label>
                <input type="text" id="materia_prima_id" name="materia_prima_id" required>

                <label for="cantidad_producida">Cantidad Producida:</label>
                <input type="number" id="cantidad_producida" name="cantidad_producida" required>

                <label for="fecha">Fecha:</label>
                <input type="date" id="fecha" name="fecha" required>

                <button type="submit" name="agregar">Registrar Proceso de Producción</button>
            </form>
        </section>

        <section>
            <h2>Lista de Procesos de Producción</h2>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Producto</th>
                        <th>Materia Prima</th>
                        <th>Cantidad</th>
                        <th>Fecha</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($producciones as $proceso): ?>
                        <tr>
                            <td><?= $proceso['id'] ?></td>
                            <td><?= $proceso['producto'] ?></td>
                            <td><?= $proceso['materia_prima'] ?></td>
                            <td><?= $proceso['cantidad_producida'] ?></td>
                            <td><?= $proceso['fecha'] ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </section>
    </main>

    <footer>
        <p>&copy; 2024 Textil Smart. Todos los derechos reservados.</p>
    </footer>
</body>
</html>
