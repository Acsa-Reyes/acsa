<?php
session_start(); // Iniciar la sesión

require_once '../config/database.php';
require_once '../src/ProductoTerminado.php';
require_once '../src/Pedido.php';
require_once '../src/Distribucion.php'; // Incluir la clase Distribucion

$productoTerminado = new ProductoTerminado($pdo);
$pedido = new Pedido($pdo); // Instanciar la clase Pedido
$distribucion = new Distribucion($pdo); // Instanciar la clase Distribucion

// Manejo de inserción de nuevo producto terminado
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['agregar'])) {
    $nombre = $_POST['nombre'];
    $descripcion = $_POST['descripcion'];
    $precio = $_POST['precio'];
    $stock = $_POST['stock'];

    try {
        // Verificar si el producto ya existe por nombre, descripción y precio
        $productoExistente = $productoTerminado->obtenerProductoTerminadoPorNombreDescripcionPrecio($nombre, $descripcion, $precio);

        if ($productoExistente) {
            // Si existe, actualizar el stock
            $nuevoStock = $productoExistente['stock'] + $stock;
            $productoTerminado->actualizarProductoTerminado($productoExistente['id'], $nombre, $descripcion, $precio, $nuevoStock);
            $_SESSION['mensaje'] = 'Stock actualizado correctamente.';
        } else {
            // Si no existe, agregarlo como nuevo
            $productoTerminado->agregarProductoTerminado($nombre, $descripcion, $precio, $stock);
            $_SESSION['mensaje'] = 'Producto agregado correctamente.';
        }
    } catch (Exception $e) {
        $_SESSION['mensaje'] = 'Error al insertar el producto: ' . $e->getMessage();
    }
}

// Manejo de eliminación de productos
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['eliminar'])) {
    $ids = $_POST['productos'] ?? [];
    foreach ($ids as $id) {
        // Primero eliminar las distribuciones asociadas al pedido
        $distribucion->eliminarDistribucionesPorPedido($id);

        // Luego eliminar el pedido
        $pedido->eliminarPedidosPorProducto($id);
        
        // Finalmente, intentar eliminar el producto
        try {
            $productoTerminado->eliminarProductoTerminado($id);
        } catch (Exception $e) {
            $_SESSION['mensaje'] = 'No se pudo eliminar el producto: ' . $e->getMessage();
        }
    }
}

// Obtener todos los productos terminados
$productosTerminados = $productoTerminado->obtenerProductosTerminados();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Productos Terminados - Textil Smart</title>
    <link rel="stylesheet" href="../public/estilos.css">
</head>
<body>
    <header>
        <h1>Gestión de Productos Terminados</h1>
    </header>

    <nav>
        <ul>
            <li><a href="../views/produccion.php">Producción</a></li>
            <li><a href="../views/pedidos.php">Pedidos</a></li>
            <li><a href="../views/materia_prima.php">Materia Prima</a></li>
            <li><a href="../views/distribucion.php">Distribución</a></li>
            <li><a href="../views/clientes.php">Clientes</a></li>
        </ul>
    </nav>

    <main>
        <section>
            <h2>Añadir Nuevo Producto Terminado</h2>
            <form method="POST">
                <label for="nombre">Nombre:</label>
                <input type="text" id="nombre" name="nombre" required>

                <label for="descripcion">Descripción:</label>
                <input type="text" id="descripcion" name="descripcion" required>

                <label for="precio">Precio:</label>
                <input type="number" id="precio" name="precio" step="0.01" required>

                <label for="stock">Stock:</label>
                <input type="number" id="stock" name="stock" required>

                <button type="submit" name="agregar">Registrar Producto Terminado</button>
            </form>
        </section>

        <section>
            <h2>Lista de Productos Terminados</h2>
            <?php if (isset($_SESSION['mensaje'])): ?>
                <div class="mensaje-exito">
                    <?= $_SESSION['mensaje'] ?>
                    <?php unset($_SESSION['mensaje']); ?>
                </div>
            <?php endif; ?>
            <form method="POST">
                <table>
                    <thead>
                        <tr>
                            <th>Seleccionar</th>
                            <th>Nombre</th>
                            <th>Descripción</th>
                            <th>Precio</th>
                            <th>Stock</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($productosTerminados as $producto): ?>
                            <tr>
                                <td><input type="checkbox" name="productos[]" value="<?= $producto['id'] ?>"></td>
                                <td><?= htmlspecialchars($producto['nombre']) ?></td>
                                <td><?= htmlspecialchars($producto['descripcion']) ?></td>
                                <td><?= htmlspecialchars($producto['precio']) ?></td>
                                <td><?= htmlspecialchars($producto['stock']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <button type="submit" name="eliminar">Eliminar Seleccionados</button>
                <button type="button" onclick="redirectToEdit()">Editar Seleccionado</button>
            </form>
        </section>
    </main>

    <footer>
        <p>&copy; 2024 Textil Smart. Todos los derechos reservados.</p>
    </footer>

    <script>
        function getSelectedId() {
            const checkboxes = document.querySelectorAll('input[name="productos[]"]:checked');
            return checkboxes.length === 1 ? checkboxes[0].value : null;
        }

        function redirectToEdit() {
            const selectedId = getSelectedId();
            if (selectedId) {
                location.href = 'editar_producto.php?id=' + selectedId;
            } else {
                alert('Por favor, selecciona un solo producto para editar.');
            }
        }
    </script>
</body>
</html>